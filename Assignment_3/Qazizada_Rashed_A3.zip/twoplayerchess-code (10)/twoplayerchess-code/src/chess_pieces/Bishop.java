package chess_pieces;

import util.Position;

import java.util.ArrayList;
import java.util.List;


public class Bishop extends AbstractChessPiece {

	public Bishop(Colour colour, Position position) {
		super(colour, position);
		pieceName = colour.getName() + "Bishop";
	}
/*

 */
	@Override
	public AbstractChessPiece clone() {
		AbstractChessPiece newClass = new Bishop(getColour(), getPosition());
		newClass.hasMoved = hasMoved;
		return newClass;
	}

	@Override
	public List<List<Position>> deriveAllMoves() {
		List<List<Position>> listHolder = new ArrayList<List<Position>>();
		AbstractChessPiece.addDiagonalTranslations(listHolder, position);
		return listHolder;
	}

}
