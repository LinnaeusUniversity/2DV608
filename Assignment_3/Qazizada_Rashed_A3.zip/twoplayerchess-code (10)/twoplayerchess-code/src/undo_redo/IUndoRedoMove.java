package undo_redo;

import chess_pieces.AbstractChessPiece;
import stalemate.ChessBoardMoment;
import util.Position;

import java.util.Map;

public interface IUndoRedoMove {
    enum Change {UNDO, REDO};

    void undo();

    void redo();

    void changeBoard(Change change);

    ChessBoardMoment getCurrentMoment();

    ChessBoardMoment getRequiredMomentForUndo();

    ChessBoardMoment getRequiredMomentForRedo();

    void setGameControllerStateInfo(ChessBoardMoment chessBoardMoment);

    void setChessPieces(ChessBoardMoment chessBoardMoment);

    void updateVisualBoard(
            Map<Position, AbstractChessPiece> currentPieces,
            Map<Position, AbstractChessPiece> intendedPieces);

    void setHighestMoveNumber(int newMoveNumber);

    void trimPreviousMoments();

    int getHighestMoveNumber();
}
