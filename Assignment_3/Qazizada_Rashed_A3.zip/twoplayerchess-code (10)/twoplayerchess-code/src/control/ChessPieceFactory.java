package control;

import chess_pieces.*;
import util.Position;

public class ChessPieceFactory {
    /*
    There are many ways to remove dependencies I moved here createChessPiece method and created this class:
    i could call createChessPiece() in every class or
    or could create an interface and each class implemented createChessPiece()
    and i could achieve. However, i decided to create class and do this way.
    Note: I also made createChessPiece non static.
     */
    public final AbstractChessPiece createChessPiece(String name, AbstractChessPiece.Colour colour, Position position) {
        if (name.equals("Pawn"))
            return new Pawn(colour, position);
        if (name.equals("Rook"))
            return new Rook(colour, position);
        if (name.equals("Knight"))
            return new Knight(colour, position);
        if (name.equals("Bishop"))
            return new Bishop(colour, position);
        if (name.equals("Queen"))
            return new Queen(colour, position);
        if (name.equals("King"))
            return new King(colour, position);
        assert false : "\"" + name + "\" is not a valid name of a chess piece class.";
        return null;
    }
}
