package control;

import chess_pieces.AbstractChessPiece;
import util.Position;

import java.util.List;

public interface IGameControllerStateInfo {

    GameControllerStateInfo clone();

    AbstractChessPiece.Colour getCurrentPlayerToMove();

    boolean isCurrentPlayerIsInCheck();

    Position getEnPassantPosition();

    int getMoveNumber();

    List<Position> getCheckBlockingMoves();
}
