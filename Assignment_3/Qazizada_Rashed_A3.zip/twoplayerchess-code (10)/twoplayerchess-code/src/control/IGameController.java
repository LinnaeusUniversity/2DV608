package control;

import chess_pieces.AbstractChessPiece;
import chess_pieces.King;
import chess_pieces.Pawn;
import gui.ChessBoard;
import stalemate.CastlingOpportunities;
import stalemate.CastlingPiecesMovementTracker;
import stalemate.ChessBoardMoment;
import stalemate.StalemateChecker;
import util.MutableBoolean;
import util.Position;

import java.util.List;

public interface IGameController {
    void go();

    void reset();

    void squareClicked(Position clickedPosition);

    void attemptPiecePlacement(Position clickedPosition);

    void moveCurrentlyHeldPiece(Position clickedPosition);

    void attemptToPickUpPiece(AbstractChessPiece clickedPiece);

    List<Position> cullIllegalMoves(List<List<Position>> initialPossibleMoves,
                                    AbstractChessPiece clickedPiece);

    List<Position> getAllowedMovesForPiece(AbstractChessPiece chessPiece);

    /*
     * Works out the line between the King and the piece. If there is such a line, it sees if
     * an opposing piece is on the end of it that would threated the King.
     */
    List<Position> getCheckedLine(AbstractChessPiece clickedPiece);

    /*
     * Calculates the line starting from the king that passes through the king. The line
     * continues until it hits a piece of either colour. Does not add the King's position
     * to the line.
     */
    List<Position> calculateSharedOpenLine(King king, AbstractChessPiece piece,
                                           MutableBoolean isDiagonalLine);

    List<Position> addPositionsOnCheckedLine(List<List<Position>> initialPossibleMoves,
                                             List<Position> checkedLine);

    void cullSpecialCases(List<Position> possibleMoves,
                          AbstractChessPiece clickedPiece);

    /*
     * This is for potentially adding castling and en passant.
     */
    void addSpecialCases(List<Position> possibleMoves, AbstractChessPiece clickedPiece);

    void replacePiece(Position clickedPosition);

    void attemptToCaptureSquare(Position clickedPosition);

    /*
     * A position is also considered to be checked when the king may temporarily be blocking check in that
     * position, but if he moves into that position, he will still be in check.
     */
    boolean positionIsChecked(Position position);

    /* This method will also get called when deciding if it's a checkmate.
     * If the king can't move anywhere without being in check, this method will get called.
     * If there's more than one threatening line, it's checkmate. If there's just one
     * threatening line, each piece on the board will have to be called to see if it can
     * move onto the line (the line being squares including the attacking piece's position,
     * excluding the position that the king is on). If none can, it's checkmate.
     * Note: A threatening line includes a pawn that's attacking the king.
     */
    List<List<Position>> getThreateningLines(Position position);

    /*
     * Short piece of logic called from getThreateningLines. Have already established that the
     * pawn is the opposite colour to the current player.
     */
    boolean isThreateningPawn(
            Pawn pawn, Position position);

    void resetColoursAfterMove();

    void determineIfCurrentPlayerIsInCheck();

    void performCastling(Position clickedPosition);

    void checkForStalemate();

    boolean isCheckmate();

    ChessBoard getChessBoard();

    AbstractChessPiece.Colour getCurrentPlayerToMove();

    ChessBoardMoment captureCurrentMoment();

    CastlingOpportunities constructCastlingOpportunities();

    boolean canCastleBetweenPositions(Position kingPosition, Position rookPosition, int direction);

    CastlingPiecesMovementTracker constructCastlingPiecesMovementTracker();

    List<Position> duplicateArrayList(List<Position> listToDuplicate);

    void nullifyPieceAndPossibleMoves();

    StalemateChecker getStalemateChecker();

    GameControllerStateInfo getGcState();

    void setGcState(GameControllerStateInfo gcState);

    int getMoveNumber();

    void undo();

    void redo();

    int getHighestRecordedMoveNumber();

    AbstractChessPiece getPieceCurrentlyHeld();

    void setPieceCurrentlyHeld(AbstractChessPiece pieceCurrentlyHeld);

    List<Position> getPossibleMoves();

    void setPossibleMoves(List<Position> possibleMoves);
}
